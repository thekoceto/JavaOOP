package unitTesting;

import org.junit.Assert;
import org.junit.Test;

public class RaceEntryTest {
    //TODO: TEST ALL THE FUNCTIONALITY OF THE PROVIDED CLASS RaceEntry
}
