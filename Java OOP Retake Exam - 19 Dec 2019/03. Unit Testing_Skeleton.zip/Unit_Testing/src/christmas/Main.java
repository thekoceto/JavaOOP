package christmas;

public class Main {
    public static void main(String[] args) {
        PresentBag pb = new PresentBag();

        //pb.create(new Present("name", 12.5));
        //Present p = new Present("name2", 13.6);
        //pb.create(p);
        pb.create(null);
       // pb.remove("name2");
        //pb.getPresent("name");
    }
}
