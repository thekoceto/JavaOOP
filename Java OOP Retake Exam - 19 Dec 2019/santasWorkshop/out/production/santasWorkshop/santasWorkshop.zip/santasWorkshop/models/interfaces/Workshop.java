package santasWorkshop.models.interfaces;

public interface Workshop {
    void craft(Present present, Dwarf dwarf);
}
