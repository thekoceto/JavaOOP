package santasWorkshop.models.dwarf;

public class Happy extends BaseDwarf{
    private static final int INITIAL_ENERGY = 100;

    public Happy(String name) {
        super(name, INITIAL_ENERGY);
    }
}
