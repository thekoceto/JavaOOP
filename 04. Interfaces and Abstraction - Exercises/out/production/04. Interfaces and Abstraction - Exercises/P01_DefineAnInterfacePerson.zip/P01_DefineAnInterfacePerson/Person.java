package P01_DefineAnInterfacePerson;

public interface Person {

    public String getName();

    public int getAge();
}
