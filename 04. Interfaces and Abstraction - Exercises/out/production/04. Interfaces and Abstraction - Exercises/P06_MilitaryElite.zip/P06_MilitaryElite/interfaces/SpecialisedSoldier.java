package P06_MilitaryElite.interfaces;

public interface SpecialisedSoldier extends Soldier {
    public String getCorps();
}
