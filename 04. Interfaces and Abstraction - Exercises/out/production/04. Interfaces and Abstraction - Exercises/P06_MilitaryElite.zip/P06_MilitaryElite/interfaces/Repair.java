package P06_MilitaryElite.interfaces;

public interface Repair {
    @Override
    String toString();
}
