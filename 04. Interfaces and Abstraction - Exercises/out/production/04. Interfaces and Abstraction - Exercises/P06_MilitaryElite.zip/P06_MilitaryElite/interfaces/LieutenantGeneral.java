package P06_MilitaryElite.interfaces;

public interface LieutenantGeneral {

    public void addPrivate(Private priv);
}
