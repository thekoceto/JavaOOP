package P06_MilitaryElite.interfaces;

public interface Commando {
    public void addMission(Mission mission);
}
