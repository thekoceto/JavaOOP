package P06_MilitaryElite.interfaces;

public interface Spy {
}
