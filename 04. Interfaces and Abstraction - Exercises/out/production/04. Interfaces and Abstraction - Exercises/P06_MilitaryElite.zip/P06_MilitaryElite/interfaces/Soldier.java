package P06_MilitaryElite.interfaces;

public interface Soldier {

    int getId();

    @Override
    public String toString();

}
