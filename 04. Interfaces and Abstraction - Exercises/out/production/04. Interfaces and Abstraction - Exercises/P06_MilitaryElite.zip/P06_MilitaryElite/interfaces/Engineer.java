package P06_MilitaryElite.interfaces;

public interface Engineer {
    public void addRepair(Repair repair);
}
