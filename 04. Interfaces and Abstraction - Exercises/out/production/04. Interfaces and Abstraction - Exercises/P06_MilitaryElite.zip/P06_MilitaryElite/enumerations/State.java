package P06_MilitaryElite.enumerations;

public enum State {
    inProgress,
    Finished,
}
