package P02_MultipleImplementation;

public interface Person {

    public String getName();

    public int getAge();
}
