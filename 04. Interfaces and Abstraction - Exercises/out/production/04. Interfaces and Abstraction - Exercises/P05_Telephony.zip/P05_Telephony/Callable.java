package P05_Telephony;

public interface Callable {
    String call();
}
