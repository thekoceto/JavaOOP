package P05_Telephony;

public interface Browsable {
    String browse();
}
