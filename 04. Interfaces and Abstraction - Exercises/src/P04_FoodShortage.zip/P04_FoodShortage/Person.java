package P04_FoodShortage;

public interface Person {

    public String getName();

    public int getAge();
}
