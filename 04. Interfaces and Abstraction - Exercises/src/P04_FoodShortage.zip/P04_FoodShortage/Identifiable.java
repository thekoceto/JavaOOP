package P04_FoodShortage;

public interface Identifiable {
    public String getId();
}
