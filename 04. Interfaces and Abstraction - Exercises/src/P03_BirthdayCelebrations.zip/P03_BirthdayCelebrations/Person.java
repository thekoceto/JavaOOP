package P03_BirthdayCelebrations;

public interface Person {

    public String getName();

    public int getAge();
}
