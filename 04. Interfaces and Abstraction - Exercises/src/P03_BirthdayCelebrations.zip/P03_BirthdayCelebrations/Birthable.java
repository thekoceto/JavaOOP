package P03_BirthdayCelebrations;

public interface Birthable {
    String getBirthDate();
}
