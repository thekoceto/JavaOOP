package app.interfaces;

public interface Private {

    double getSalary();
}
