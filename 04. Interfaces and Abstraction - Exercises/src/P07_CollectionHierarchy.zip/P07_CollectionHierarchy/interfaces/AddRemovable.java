package P07_CollectionHierarchy.interfaces;

public interface AddRemovable extends Addable{
    String remove();
}
