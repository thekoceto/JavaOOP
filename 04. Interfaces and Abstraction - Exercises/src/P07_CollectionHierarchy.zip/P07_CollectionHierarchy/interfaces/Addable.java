package P07_CollectionHierarchy.interfaces;

public interface Addable {
    int add(String element);
}
