package P07_CollectionHierarchy.interfaces;

public interface MyList extends AddRemovable {
    int getUsed();
}
