package P05_Restaurant;

public class Main {
    public static void main(String[] args) {

    }
}
