package P05_BarracksWars.interfaces;

public interface Executable {

	String execute();

}
