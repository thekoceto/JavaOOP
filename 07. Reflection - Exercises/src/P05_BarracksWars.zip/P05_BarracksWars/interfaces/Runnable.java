package P05_BarracksWars.interfaces;

public interface Runnable {
	void run();
}
