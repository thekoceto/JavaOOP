package P05_BarracksWars.interfaces;

public interface Unit extends Destroyable, Attacker {
}
