package P04_BarracksWars.interfaces;

public interface Runnable {
	void run();
}
