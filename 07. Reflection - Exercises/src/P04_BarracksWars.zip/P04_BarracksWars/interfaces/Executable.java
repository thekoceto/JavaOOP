package P04_BarracksWars.interfaces;

public interface Executable {

	String execute();

}
