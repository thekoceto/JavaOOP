package P03_BarracksWars.interfaces;

public interface Executable {

	String execute();

}
