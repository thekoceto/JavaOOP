package P03_BarracksWars.interfaces;

public interface Attacker {
    
    int getAttackDamage();
}
