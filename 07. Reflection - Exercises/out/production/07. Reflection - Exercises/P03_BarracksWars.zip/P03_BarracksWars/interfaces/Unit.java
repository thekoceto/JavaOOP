package P03_BarracksWars.interfaces;

public interface Unit extends Destroyable, Attacker {
}
