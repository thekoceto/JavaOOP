package CounterStriker.models.field;

import CounterStriker.models.players.Player;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class FieldImpl implements Field{
    List<Player> terrorists = new ArrayList<>();
    List<Player> counterTerrorists = new ArrayList<>();

    @Override
    public String start(Collection<Player> players) {
        for (Player player : players) {
            if (player.getClass().getSimpleName().equals("Terrorist"))
                terrorists.add(player);
            else if (player.getClass().getSimpleName().equals("CounterTerrorist"))
                counterTerrorists.add(player);
        }

        while (!haveTeamWithDeadPlayers(terrorists, counterTerrorists)){
            oneStepFromAttack(terrorists, counterTerrorists);
            oneStepFromAttack(counterTerrorists, terrorists);
        }

        int terroristsHealth = terrorists.stream().mapToInt(Player::getHealth).sum();
        return terroristsHealth > 0 ? "Terrorist wins!" : "Counter Terrorist wins!";
    }

//    private void oneStepFromAttack(List<Player> attackers, List<Player> targets) {
//        for (Player attacker : attackers) {
//            if (attacker.isAlive()){
//                for (Player target : targets) {
//                    if (target.isAlive()) {
//                        target.takeDamage(attacker.getGun().fire());
//                    }
//                }
//            }
//        }
//    }

    private void oneStepFromAttack(List<Player> attackers, List<Player> targets) {
        for (Player player : attackers) {
            if(player.isAlive()){
                for (Player counterTerrorist : targets) {
                    if(!haveTeamWithDeadPlayers(terrorists, counterTerrorists)) {
                        int bullets = player.getGun().fire();
                        if (counterTerrorist.isAlive()) {
                            counterTerrorist.takeDamage(bullets);
                        }
                    }
                    else{
                        break;
                    }
                }
            }
        }
    }

    private boolean haveTeamWithDeadPlayers(List<Player> terrorists, List<Player> counterTerrorists) {
        boolean allTerroristsDead = terrorists
                .stream()
                .mapToInt(Player::getHealth)
                .sum() <= 0;

        boolean allCounterTerroristsDead = counterTerrorists
                .stream()
                .mapToInt(Player::getHealth)
                .sum() <= 0;

        return allTerroristsDead || allCounterTerroristsDead;
    }
}
