package heroRepository;

import static org.junit.Assert.*;

public class HeroRepositoryTest {
    //TODO: TEST ALL THE FUNCTIONALITY OF THE PROVIDED CLASS HeroRepository

}