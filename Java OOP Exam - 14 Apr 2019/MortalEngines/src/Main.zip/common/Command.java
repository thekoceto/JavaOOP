package common;

public enum Command {
    Hire,
    Report,
    ManufactureTank,
    ManufactureFighter,
    Engage,
    Attack,
    AggressiveMode,
    DefenseMode,
    Over
}
