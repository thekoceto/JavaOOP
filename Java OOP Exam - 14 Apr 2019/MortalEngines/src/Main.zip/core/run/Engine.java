package core.run;

public interface Engine extends Runnable {
}
