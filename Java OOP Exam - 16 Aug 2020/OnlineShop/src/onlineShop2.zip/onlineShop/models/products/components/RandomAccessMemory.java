package onlineShop.models.products.components;

public class RandomAccessMemory extends BaseComponent{
    private static final double MULTIPLIER = 1.2d;

    public RandomAccessMemory(int id, String manufacturer, String model, double price, double overallPerformance, int generation) {
        super(id, manufacturer, model, price, overallPerformance, generation);
        super.setOverallPerformance(super.getOverallPerformance() * MULTIPLIER);
    }

}
