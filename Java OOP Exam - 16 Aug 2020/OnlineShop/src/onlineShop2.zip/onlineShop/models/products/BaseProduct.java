package onlineShop.models.products;

import onlineShop.common.constants.ExceptionMessages;

public abstract class BaseProduct implements Product{
    private int id;
    private String manufacturer;
    private String model;
    private double price;
    private double overallPerformance;

    public BaseProduct(int id, String manufacturer, String model, double price, double overallPerformance) {
        this.setId(id);
        this.setManufacturer(manufacturer);
        this.setModel(model);
        this.setPrice(price);
        this.setOverallPerformance(overallPerformance);
    }


    //•	id – int
    //o	cannot be less than or equal to 0. In that case, throw IllegalArgumentException
    // with message "Id can not be less or equal than 0."
    public void setId(int id) {
        if (id <= 0)
            throw new IllegalArgumentException(ExceptionMessages.INVALID_PRODUCT_ID);

        this.id = id;
    }

    //•	manufacturer – String
    //o	cannot be null or whitespace. In that case, throw IllegalArgumentException
    // with message "Manufacturer can not be empty.
    public void setManufacturer(String manufacturer) {
        if (manufacturer==null || manufacturer.trim().isEmpty())
            throw new IllegalArgumentException(ExceptionMessages.INVALID_MANUFACTURER);

        this.manufacturer = manufacturer;
    }

    //•	model – String
    //o	cannot be null or whitespace. In that case, throw IllegalArgumentException
    // with message "Model can not be empty."
    public void setModel(String model) {
        if (model==null || model.trim().isEmpty())
            throw new IllegalArgumentException(ExceptionMessages.INVALID_MODEL);

        this.model = model;
    }


    //•	price – double
    //o	cannot be less than or equal to 0. In that case, throw IllegalArgumentException
    // with message "Price can not be less or equal than 0."
    public void setPrice(double price) {
        if (price <= 0d)
            throw new IllegalArgumentException(ExceptionMessages.INVALID_PRICE);

        this.price = price;
    }

    //•	overallPerformance – double
    //o	cannot be less than or equal to 0. In that case, throw IllegalArgumentException
    // with message "Overall Performance can not be less or equal than 0."
    public void setOverallPerformance(double overallPerformance) {
        if (overallPerformance <= 0d)
            throw new IllegalArgumentException(ExceptionMessages.INVALID_OVERALL_PERFORMANCE);

        this.overallPerformance = overallPerformance;
    }

    @Override
    public int getId() {
        return this.id;
    }

    @Override
    public String getManufacturer() {
        return this.manufacturer;
    }

    @Override
    public String getModel() {
        return this.model;
    }

    @Override
    public double getPrice() {
        return this.price;
    }

    @Override
    public double getOverallPerformance() {
        return this.overallPerformance;
    }

    //"Overall Performance: {overall performance}. Price: {price} - {product type}: {manufacturer} {model} (Id: {id})"
    @Override
    public String toString() {
        return String.format("Overall Performance: %.2f. Price: %.2f - %s: %s %s (Id: %d)",
                this.overallPerformance, this.price, this.getClass().getSimpleName(),
                this.manufacturer, this.model, this.id);

    }
}
