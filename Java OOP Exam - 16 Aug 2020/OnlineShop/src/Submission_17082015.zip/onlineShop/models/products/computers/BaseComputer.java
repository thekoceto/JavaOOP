package onlineShop.models.products.computers;

import onlineShop.common.constants.ExceptionMessages;
import onlineShop.models.products.BaseProduct;
import onlineShop.models.products.Product;
import onlineShop.models.products.components.Component;
import onlineShop.models.products.peripherals.Peripheral;

import java.util.ArrayList;
import java.util.List;

public class BaseComputer extends BaseProduct implements Computer{
    private List<Component> components;
    private List<Peripheral> peripherals;

    public BaseComputer(int id, String manufacturer, String model, double price, double overallPerformance) {
        super(id, manufacturer, model, price, overallPerformance);
        this.components = new ArrayList<>();
        this.peripherals = new ArrayList<>();
    }

    //Override toString() method in the format:
    //"Overall Performance: {overall performance}. Price: {price} - {product type}: {manufacturer} {model} (Id: {id})"
    //" Components ({components count}):"
    //"  {component one}"
    //"  {component two}"
    //"  {component n}"
    //" Peripherals ({peripherals count}); Average Overall Performance ({average overall performance peripherals}):"
    //"  {peripheral one}"
    //"  {peripheral two}"
    //"  {peripheral n}"
    @Override
    public String toString() {
        StringBuilder info = new StringBuilder();

        info.append(super.toString()).append(System.lineSeparator());

        info.append(" Components (").append(this.components.size()).append("):")
                .append(System.lineSeparator());

        this.components.forEach(component -> info
                .append("  ")
                .append(component.toString())
                .append(System.lineSeparator()));

        double averageOverallPerformance =
                this.peripherals.stream()
                        .mapToDouble(Product::getOverallPerformance)
                        .average()
                        .orElse(0d);

        info.append(" Peripherals (").append(this.peripherals.size())
                .append(String.format("); Average Overall Performance (%.2f):", averageOverallPerformance))
                .append(System.lineSeparator());

        this.peripherals.forEach(peripheral -> info
                .append("  ")
                .append(peripheral.toString())
                .append(System.lineSeparator()));

        return info.toString().trim();
    }



    @Override
    public double getOverallPerformance() {
        if (this.components.isEmpty())
            return super.getOverallPerformance();

        double averageOverallPerformance =
                this.components.stream()
                        .mapToDouble(Product::getOverallPerformance)
                        .average()
                        .orElse(0d);

        return super.getOverallPerformance() + averageOverallPerformance;
    }

    @Override
    public double getPrice() {
        double componentsPrice = this.components.stream()
                .mapToDouble(Product::getPrice)
                .sum();
        double peripheralsPrice = this.peripherals.stream()
                .mapToDouble(Product::getPrice)
                .sum();

        return super.getPrice() + componentsPrice + peripheralsPrice;
    }

    @Override
    public List<Peripheral> getPeripherals() {
        return this.peripherals;
    }

    @Override
    public List<Component> getComponents() {
        return this.components;
    }

    @Override
    public void addComponent(Component component) {
        String componentType = component.getClass().getSimpleName();

        for (Component currentComponent : this.components) {
            if (componentType.equals(currentComponent.getClass().getSimpleName()))
                throw new IllegalArgumentException(
                        String.format(ExceptionMessages.EXISTING_COMPONENT
                                ,currentComponent.getClass().getSimpleName()
                                ,this.getClass().getSimpleName()
                                ,this.getId()));
                //message "Component {component type} already exists in {computer type} with Id {id}.
        }
        this.components.add(component);
    }

    @Override
    public Component removeComponent(String componentType) {

        for (Component component : components) {
            if (component.getClass().getSimpleName().equals(componentType)){
                components.remove(component);
                return component;
            }
        }
        throw new IllegalArgumentException(
                String.format(ExceptionMessages.NOT_EXISTING_COMPONENT
                        ,componentType
                        ,this.getClass().getSimpleName()
                        ,this.getId()));
        // "Component {component type} does not exist in {computer type} with Id {id}.
    }

    @Override
    public void addPeripheral(Peripheral peripheral) {
        String peripheralType = this.peripherals.getClass().getSimpleName();

        for (Peripheral currentPeripheral : this.peripherals) {
            if (peripheralType.equals(currentPeripheral.getClass().getSimpleName()))
                throw new IllegalArgumentException(
                        String.format(ExceptionMessages.EXISTING_PERIPHERAL
                                ,currentPeripheral.getClass().getSimpleName()
                                ,this.getClass().getSimpleName()
                                ,this.getId()));
            //Peripheral {peripheral type} already exists in {computer type} with Id {id}.
        }
        this.peripherals.add(peripheral);
    }

    @Override
    public Peripheral removePeripheral(String peripheralType) {

        for (Peripheral peripheral : this.peripherals) {
            if (peripheral.getClass().getSimpleName().equals(peripheralType)){
                this.peripherals.remove(peripheral);
                return peripheral;
            }
        }
        throw new IllegalArgumentException(
                String.format(ExceptionMessages.NOT_EXISTING_PERIPHERAL
                        ,peripheralType
                        ,this.getClass().getSimpleName()
                        ,this.getId()));
        //"Peripheral {peripheral type} does not exist in {computer type} with Id {id}."
    }

    private double getAverageOverallPerformance (List<BaseProduct> products){
        return products.stream()
                .mapToDouble(Product::getOverallPerformance)
                .average()
                .orElse(0d);
    }

}
