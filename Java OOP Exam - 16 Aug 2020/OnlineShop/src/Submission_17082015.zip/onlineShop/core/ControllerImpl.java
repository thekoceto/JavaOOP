package onlineShop.core;

import onlineShop.common.constants.ExceptionMessages;
import onlineShop.common.constants.OutputMessages;
import onlineShop.core.interfaces.Controller;
import onlineShop.models.products.Product;
import onlineShop.models.products.components.*;
import onlineShop.models.products.computers.Computer;
import onlineShop.models.products.computers.DesktopComputer;
import onlineShop.models.products.computers.Laptop;
import onlineShop.models.products.peripherals.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ControllerImpl implements Controller {
    private List<Computer> computers;
    private List<Component> components;
    private List<Peripheral> peripherals;
    // ? collection of peripherals in the controller

    public ControllerImpl() {
        this.computers = new ArrayList<>();
        this.components = new ArrayList<>();
        this.peripherals = new ArrayList<>();
    }

    @Override
    public String addComputer(String computerType, int id, String manufacturer, String model, double price) {
        checkComputerIdExist(id);
        switch (computerType){
            case "DesktopComputer":
                this.computers.add(new DesktopComputer(id, manufacturer, model, price));
                return String.format(OutputMessages.ADDED_COMPUTER, id);
            case "Laptop":
                this.computers.add(new Laptop(id, manufacturer, model, price));
                return String.format(OutputMessages.ADDED_COMPUTER, id);
            default:
                throw new IllegalArgumentException(ExceptionMessages.INVALID_COMPUTER_TYPE);

        }
    }

    @Override
    public String addPeripheral(int computerId, int id, String peripheralType, String manufacturer, String model, double price, double overallPerformance, String connectionType) {
        Computer computer = checkComputerIdNotExist(computerId);

        if (getPeripheral(id, computer) != null)
            throw new IllegalArgumentException(ExceptionMessages.EXISTING_PERIPHERAL_ID);

        Peripheral peripheral;
        switch (peripheralType) {
            case "Headset":
                peripheral = new Headset(id, manufacturer, model, price, overallPerformance, connectionType);
                computer.addPeripheral(peripheral);
                this.peripherals.add(peripheral);
                return String.format(OutputMessages.ADDED_PERIPHERAL, peripheralType, id, computerId);
            case "Keyboard":
                peripheral = new Keyboard(id, manufacturer, model, price, overallPerformance, connectionType);
                computer.addPeripheral(peripheral);
                this.peripherals.add(peripheral);
                return String.format(OutputMessages.ADDED_PERIPHERAL, peripheralType, id, computerId);
            case "Monitor":
                peripheral = new Monitor(id, manufacturer, model, price, overallPerformance, connectionType);
                computer.addPeripheral(peripheral);
                this.peripherals.add(peripheral);
                return String.format(OutputMessages.ADDED_PERIPHERAL, peripheralType, id, computerId);
            case "Mouse":
                peripheral = new Mouse(id, manufacturer, model, price, overallPerformance, connectionType);
                computer.addPeripheral(peripheral);
                this.peripherals.add(peripheral);
                return String.format(OutputMessages.ADDED_PERIPHERAL, peripheralType, id, computerId);
            default:
                throw new IllegalArgumentException(ExceptionMessages.INVALID_PERIPHERAL_TYPE);
        }
    }

    @Override
    public String removePeripheral(String peripheralType, int computerId) {

        Computer computer = checkComputerIdNotExist(computerId);

        Peripheral peripheral = computer.removePeripheral(peripheralType);
        this.peripherals.remove(peripheral);

        return String.format(OutputMessages.REMOVED_PERIPHERAL, peripheralType, peripheral.getId());
    }

    @Override
    public String addComponent(int computerId, int id, String componentType, String manufacturer, String model, double price, double overallPerformance, int generation) {
        Computer computer = checkComputerIdNotExist(computerId);
        if (getComponent(id, computer) != null)
            throw new IllegalArgumentException(ExceptionMessages.EXISTING_COMPONENT_ID);

        Component component;
        switch (componentType){
            case "CentralProcessingUnit":
                component = new CentralProcessingUnit(id, manufacturer, model, price, overallPerformance, generation);
                computer.addComponent(component);
                this.components.add(component);
                return String.format(OutputMessages.ADDED_COMPONENT, componentType, id, computerId);
            case "Motherboard":
                component = new Motherboard(id, manufacturer, model, price, overallPerformance, generation);
                computer.addComponent(component);
                this.components.add(component);
                return String.format(OutputMessages.ADDED_COMPONENT, componentType, id, computerId);
            case "PowerSupply":
                component = new PowerSupply(id, manufacturer, model, price, overallPerformance, generation);
                computer.addComponent(component);
                this.components.add(component);
                return String.format(OutputMessages.ADDED_COMPONENT, componentType, id, computerId);
            case "RandomAccessMemory":
                component = new RandomAccessMemory(id, manufacturer, model, price, overallPerformance, generation);
                computer.addComponent(component);
                this.components.add(component);
                return String.format(OutputMessages.ADDED_COMPONENT, componentType, id, computerId);
            case "SolidStateDrive":
                component = new SolidStateDrive(id, manufacturer, model, price, overallPerformance, generation);
                computer.addComponent(component);
                this.components.add(component);
                return String.format(OutputMessages.ADDED_COMPONENT, componentType, id, computerId);
            case "VideoCard":
                component = new VideoCard(id, manufacturer, model, price, overallPerformance, generation);
                computer.addComponent(component);
                this.components.add(component);
                return String.format(OutputMessages.ADDED_COMPONENT, componentType, id, computerId);
            default:
                throw new IllegalArgumentException(ExceptionMessages.INVALID_COMPONENT_TYPE);
        }
    }

    @Override
    public String removeComponent(String componentType, int computerId) {
        Computer computer = checkComputerIdNotExist(computerId);

        Component component = computer.removeComponent(componentType);
        this.components.remove(component);

        return String.format(OutputMessages.REMOVED_COMPONENT, componentType, component.getId());
    }

    @Override
    public String buyComputer(int id) {
        Computer computer = checkComputerIdNotExist(id);

        this.computers.remove(computer);

        return computer.toString();
    }

    @Override
    public String BuyBestComputer(double budget) {
        Computer bestComputer = this.computers.stream()
                .max(Comparator.comparing(Computer::getOverallPerformance))
                .orElse(null);
        if (bestComputer == null)
            throw new IllegalArgumentException (String.format(ExceptionMessages.CAN_NOT_BUY_COMPUTER, budget));

        this.computers.remove(bestComputer);

        return bestComputer.toString();
    }
    // Removes the computer with the highest overall performance and with a price,
    // less or equal to the budget, from the collection of computers.

    @Override
    public String getComputerData(int id) {
        Computer computer = checkComputerIdNotExist(id);

        return computer.toString();
    }

    private Computer checkComputerIdNotExist(int computerId){
        Computer computer = getComputerWithID(computerId);

        if (getComputerWithID(computerId) == null)
            throw new IllegalArgumentException(ExceptionMessages.NOT_EXISTING_COMPUTER_ID);

        return computer;

    }

    private void checkComputerIdExist(int computerId){
        if (getComputerWithID(computerId) != null)
            throw new IllegalArgumentException(ExceptionMessages.EXISTING_COMPUTER_ID);
    }

    private Computer getComputerWithID(int computerId) {
        return this.computers
                .stream()
                .filter(current -> current.getId() == computerId)
                .findFirst().orElse(null);
    }

    private Component getComponent(int componentId, Computer computer) {
        return computer.getComponents()
                .stream()
                .filter(component -> component.getId() == componentId)
                .findFirst()
                .orElse(null);
    }
    private Peripheral getPeripheral(int peripheralId, Computer computer) {
        return computer.getPeripherals()
                .stream()
                .filter(peripheral -> peripheral.getId() == peripheralId)
                .findFirst()
                .orElse(null);
    }
}
