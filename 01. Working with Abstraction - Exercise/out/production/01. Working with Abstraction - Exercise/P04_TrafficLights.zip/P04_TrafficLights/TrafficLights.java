/*
 * Copyright (c) 2020.
 * thekoceto@gmail.com
 */

package P04_TrafficLights;

public enum TrafficLights {
    RED(0), GREEN(1), YELLOW(2);

    private int index;

    TrafficLights(int index) {
        this.index = index;
    }

    public int getIndex() {
        return index;
    }

    public TrafficLights getTrafficLightsByIndex (int index){
        for (TrafficLights value : TrafficLights.values()) {
            if (value.index == index)
                return value;
        }
        return null;
    }
}
