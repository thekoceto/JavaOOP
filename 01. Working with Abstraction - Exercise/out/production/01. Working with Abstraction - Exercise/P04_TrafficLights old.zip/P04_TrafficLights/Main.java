package P04_TrafficLights;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        TrafficLights[] lights = Arrays
                .stream(reader.readLine().split(" "))
                .map(TrafficLights::valueOf)
                .toArray(TrafficLights[]::new);

        int n = Integer.parseInt(reader.readLine());

        StringBuilder out = new StringBuilder();

        TrafficLights[] trafficLights = TrafficLights.values();

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < lights.length; j++) {
                TrafficLights light = lights[j];

                int nextIndex = light.ordinal() + 1;
                TrafficLights value = trafficLights[nextIndex % trafficLights.length];
                lights[j] = value;
                out.append(value).append(j < lights.length-1 ? " " : "");
            }
            out.append(System.lineSeparator());
        }
        System.out.print(out.toString().trim());
    }
}