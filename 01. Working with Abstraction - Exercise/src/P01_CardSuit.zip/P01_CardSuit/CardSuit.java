package P01_CardSuit;

public enum CardSuit {
    CLUBS, DIAMONDS, HEARTS, SPADES;

}
