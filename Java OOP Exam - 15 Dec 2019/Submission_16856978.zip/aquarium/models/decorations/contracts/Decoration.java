package aquarium.models.decorations.contracts;

public interface Decoration {
    int getComfort();

    double getPrice();
}
