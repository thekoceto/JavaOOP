package aquarium.core.contracts;

public interface Engine extends Runnable {
}

