package aquarium.core;

import aquarium.common.ConstantMessages;
import aquarium.common.ExceptionMessages;
import aquarium.core.contracts.Controller;
import aquarium.models.aquariums.FreshwaterAquarium;
import aquarium.models.aquariums.SaltwaterAquarium;
import aquarium.models.aquariums.contracts.Aquarium;
import aquarium.models.decorations.Ornament;
import aquarium.models.decorations.Plant;
import aquarium.models.decorations.contracts.Decoration;
import aquarium.models.fish.FreshwaterFish;
import aquarium.models.fish.SaltwaterFish;
import aquarium.models.fish.contracts.Fish;
import aquarium.repositories.DecorationRepository;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public class ControllerImpl implements Controller {


    private DecorationRepository decorationRepository;
    private Map<String, Aquarium> aquariums;

    public ControllerImpl() {
        decorationRepository = new DecorationRepository();
        aquariums = new LinkedHashMap<>();

    }

    @Override
    public String addAquarium(String aquariumType, String aquariumName) {

        Aquarium aquarium;
        if (aquariumType.equals("FreshwaterAquarium")) {
            aquarium = new FreshwaterAquarium(aquariumName);
            this.aquariums.putIfAbsent(aquariumName, aquarium);

        } else if (aquariumType.equals("SaltwaterAquarium")) {
            aquarium = new SaltwaterAquarium(aquariumName);
            this.aquariums.putIfAbsent(aquariumName, aquarium);

        } else {
            throw new IllegalArgumentException(ExceptionMessages.INVALID_AQUARIUM_TYPE);
        }

        return String.format(ConstantMessages.SUCCESSFULLY_ADDED_AQUARIUM_TYPE, aquariumType);
    }

    @Override
    public String addDecoration(String type) {

        Decoration decoration;
        if (type.equals("Ornament")) {
            decoration = new Ornament();
            this.decorationRepository.add(decoration); /// не е unmodif !

        } else if (type.equals("Plant")) {
            decoration = new Plant();
            this.decorationRepository.add(decoration);

        } else {
            throw new IllegalArgumentException(ExceptionMessages.INVALID_DECORATION_TYPE);
        }

        return String.format(ConstantMessages.SUCCESSFULLY_ADDED_DECORATION_TYPE, type);

    }

    @Override
    public String insertDecoration(String aquariumName, String decorationType) {
        String msg;
        Decoration byType = this.decorationRepository.findByType(decorationType);

        if (byType == null) {
            msg = String.format(ExceptionMessages.NO_DECORATION_FOUND, decorationType);
            throw new IllegalArgumentException(msg);
        }

        Aquarium aquarium = this.aquariums.get(aquariumName);
        aquarium.addDecoration(byType);
        this.decorationRepository.remove(byType);

        msg = String.format(ConstantMessages.SUCCESSFULLY_ADDED_DECORATION_IN_AQUARIUM, decorationType, aquariumName);
        return msg;
    }

    @Override
    public String addFish(String aquariumName, String fishType, String fishName, String fishSpecies, double price) {
        boolean isFreshWaterFish = false;
        boolean isSaltWaterFish = false;

        Fish currentFish;

        if (fishType.equals("FreshwaterFish")) {
            isFreshWaterFish = true;
            currentFish = new FreshwaterFish(fishName, fishSpecies, price);

        } else if (fishType.equals("SaltwaterFish")) {

            isSaltWaterFish = true;
            currentFish = new SaltwaterFish(fishName, fishSpecies, price);

        } else {
            throw new IllegalArgumentException(ExceptionMessages.INVALID_FISH_TYPE);
        }

        Aquarium aquarium = this.aquariums.get(aquariumName);


//        try {
            aquarium.addFish(currentFish);

            if (aquarium.getClass().getSimpleName().contains("Fresh") && isFreshWaterFish) {

                return String.format(ConstantMessages.SUCCESSFULLY_ADDED_FISH_IN_AQUARIUM, fishType, aquariumName);

            } else
                if (aquarium.getClass().getSimpleName().contains("Salt") && isSaltWaterFish) {

                return String.format(ConstantMessages.SUCCESSFULLY_ADDED_FISH_IN_AQUARIUM, fishType, aquariumName);

            } else {
               return ConstantMessages.WATER_NOT_SUITABLE;
            }

//        } catch (IllegalStateException iae) {
//            return iae.getMessage();
//        }

    }

    @Override
    public String feedFish(String aquariumName) {
        Aquarium aquarium = this.aquariums.get(aquariumName);
        aquarium.feed();
        return String.format(ConstantMessages.FISH_FED, aquarium.getFish().size());
    }

    @Override
    public String calculateValue(String aquariumName) {
        Aquarium aquarium = this.aquariums.get(aquariumName);
        double sumFishPrices = aquarium.getFish().stream().mapToDouble(Fish::getPrice).sum();
        double sumDecorationsPrice = aquarium.getDecorations().stream().mapToDouble(Decoration::getPrice).sum();

        double value = sumFishPrices + sumDecorationsPrice;

        return String.format(ConstantMessages.VALUE_AQUARIUM, aquariumName, value);

    }

    @Override
    public String report() {
        StringBuilder reportPerPrint = new StringBuilder();

        for (Aquarium value : aquariums.values()) {
            reportPerPrint
                    .append(value.getInfo())
                    .append(System.lineSeparator());
        }

        return reportPerPrint.toString();
    }
}
