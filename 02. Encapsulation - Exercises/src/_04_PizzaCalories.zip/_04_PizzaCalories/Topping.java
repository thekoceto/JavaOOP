package _04_PizzaCalories;

public class Topping {
    private String toppingType;
    private double weight;
    private double toppingModifier;

    //+ Topping (String, double)
    public Topping(String toppingType, double weight) {
        this.setToppingType(toppingType);
        this.setWeight(weight);
    }

    //-	setToppingType (String): void
    private void setToppingType(String toppingType) {
        this.toppingType = toppingType;
        switch (this.toppingType) {
            case "Meat":
                this.toppingModifier = 1.2;
                break;
            case "Sauce":
                this.toppingModifier = 0.9;
                break;
            case "Veggies":
                this.toppingModifier = 0.8;
                break;
            case "Cheese":
                this.toppingModifier = 1.1;
                break;
            default:
                throw new IllegalArgumentException(String.format("Cannot place %s on top of your pizza.",toppingType));
        }

    }

    //-	setWeight (double): void
    private void setWeight(double weight) {
        if (weight<1 || weight>50) {
            throw new IllegalArgumentException(String.format("%s weight should be in the range [1..50].",this.toppingType));
        }
        this.weight = weight;
    }

    //+	calculateCalories (): double
    public double calculateCalories() {
        return (2*this.weight)*this.toppingModifier;
    }
}