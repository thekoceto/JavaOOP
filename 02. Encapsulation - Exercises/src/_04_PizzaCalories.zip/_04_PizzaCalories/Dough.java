package _04_PizzaCalories;

public class Dough {
    private String flourType;
    private String bakingTechnique;
    private double weight;

    private double flourModifier;
    private double bakingModifier;

    //+ Dough (String, String, double)
    public Dough(String flourType, String bakingTechnique, double weight) {
        setFlourType(flourType);
        setBakingTechnique(bakingTechnique);
        setWeight(weight);
    }

    //-	setWeight(double): void
    private void setWeight(double weight) {
        if (weight<1 || weight>200) {
            throw new IllegalArgumentException("Dough weight should be in the range [1..200].");
        }
        this.weight = weight;
    }

    //-	setFlourType(String): void
    private void setFlourType(String flourType) {
        this.flourType = flourType;   // here
        switch (this.flourType) {
            case "Wholegrain":
                this.flourModifier = 1.0;
                break;
            case "White":
                this.flourModifier = 1.5;
                break;
            default:
                throw new IllegalArgumentException("Invalid type of dough.");
        }
    }

    //-	setBakingTechnique(String): void
    private void setBakingTechnique(String bakingTechnique) {
        this.bakingTechnique = bakingTechnique;
        switch (this.bakingTechnique) {
            case "Crispy":
                this.bakingModifier = 0.9;
                break;
            case "Chewy":
                this.bakingModifier = 1.1;
                break;
            case "Homemade":
                this.bakingModifier = 1.0;
                break;
            default:
                throw new IllegalArgumentException("Invalid type of dough.");
        }
    }

    //+	calculateCalories (): double
    public double calculateCalories() {
        return (2*this.weight)*this.bakingModifier*this.flourModifier;
    }

}