package _04_PizzaCalories;

import java.util.ArrayList;
import java.util.List;

public class Pizza {
    private String name;
    private Dough dough;
    private List<Topping> toppings;

    public Pizza(String name, int numberOfToppings) {
        setName(name);
        this.setToppings(numberOfToppings);
    }

    //-	setName(String) : void
    private void setName(String name) {
        if (name.trim().isEmpty() || name.length()>15) {
            throw new IllegalArgumentException("Pizza name should be between 1 and 15 symbols.");
        }
        this.name = name;
    }

    //+	setDough(Dough) : void
    public void setDough(Dough dough) {
        this.dough = dough;
    }

    //-	setToppings(int) : void
    private void setToppings(int numberOfToppings) {
        if (numberOfToppings<1 || numberOfToppings>10) {
            throw new IllegalArgumentException("Number of toppings should be in range [1..10].");
        }
        this.toppings= new ArrayList<>();
    }

    //+	getName(): String
    public String getName() {
        return this.name;
    }

    //+	addTopping (Topping) : void
    public void addTopping(Topping topping) {
        this.toppings.add(topping);
    }

    //+	getOverallCalories () : double
    public double getOverallCalories() {
        return this.dough.calculateCalories() +
                this.toppings
                        .stream()
                        .mapToDouble(Topping::calculateCalories)
                        .sum();
    }

    private Dough getDough() { // correct
        return dough;
    }

    private List<Topping> getToppings() { // correct
        return toppings;
    }
}